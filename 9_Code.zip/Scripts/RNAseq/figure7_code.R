library(reshape2)  
library(plyr)  
library(devtools)
library(data.table)

#############   FUNCTIONS ############# 
importData <- function(tpmFile=NULL, metaFile=NULL, programFile=NULL, rel_sym_ncbi_File=NULL ){
  ## File unique associations symbols-ncbi
  rel_sym_ncbi <- read.csv(rel_sym_ncbi_File, header=T, as.is=T, sep="\t")
  codingGenes <- subset(rel_sym_ncbi, type =="protein-coding")  
  dlg2.ncbi <- "1740" 
  # Import expression values and meta data for Nowakowsky dataset
  sc.tpm <- fread(tpmFile ) # 
  sc.meta <- read.csv(metaFile, header=T, as.is=T,sep="\t") # 
  ## define cell-type classes
  {
    MatureExcNeuron <- c("EN-PFC1", "EN-PFC2", "EN-PFC3", "EN-V1-1", "EN-V1-2", "EN-V1-3") # 93, 96, 53, 166, 182, 76 => 666
    IPCs <- c("IPC-div1", "IPC-div2") #  36,51 ==> 87                     , 36,51, 68,76,39 => 270
    NewbornExcNeuron <- c("nEN-early1", "nEN-early2", "nEN-late") # 52, 455, 321 => 828
    NewbornMGENeuron <- c("nIN1", "nIN2","nIN3", "nIN4", "nIN5" ) #  72,96,54,28,64 => 314
    RadialGlia <- c("RG-div1", "RG-div2", "oRG", "tRG", "vRG") # 133,124,65,100,97
    EarlyRadialGlia <- c("RG-early") #    53
    Transition <- c("IPC-nEN1", "IPC-nEN2", "IPC-nEN3") #   68,76,39 => 183
    
    sc.meta$CellType <- "none"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% MatureExcNeuron] <- "Mature"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% IPCs] <- "IPCs"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% NewbornExcNeuron] <- "Newborn"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% RadialGlia] <- "RadialGlia"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% EarlyRadialGlia] <- "EarlyRadialGlia"
    sc.meta$CellType[sc.meta$WGCNAcluster %in% Transition] <- "Transition"
  }
  ## import program gene-sets
  geneLists <-  read.csv(programFile, header=F, sep="\t"  )
  sets.list <- list()
  for(set in  geneLists$V1){
    tmp <- subset(geneLists,V1==set   )
    sets.list[[set]] <- as.data.frame(strsplit(as.character(tmp$V2), " " ))
    colnames( sets.list[[set]]) <- "Gene"
    sets.list[[set]]   <-  merge(   sets.list[[set]]  , unique(subset(rel_sym_ncbi,  select=c(ncbi, symbol))), by.x="Gene", by.y="ncbi")  
    colnames( sets.list[[set]])[[2]] <- "Symbol"
  }
  ## Reduce the matrix to protein coding genes and selected cell types
  developmentEX.cells <- subset(sc.meta, CellType!="none")
  sc.tpm.my <- subset(sc.tpm, select=c("gene",developmentEX.cells$Cell))
  sc.tpm.coding <- subset(sc.tpm.my, gene %in% codingGenes$symbol) 
  rm(sc.tpm.my)
  
  return(list(sc.tpm.coding=sc.tpm.coding,developmentEX.cells= developmentEX.cells,sets.list=sets.list,rel_sym_ncbi=rel_sym_ncbi))
}
filter_and_zscore <- function(sc.tpm.coding, rel_sym_ncbi,cellTypeThrs, geneThrs){
  ## Filtering
  sc.tpm.coding.df <- as.data.frame(sc.tpm.coding)
  ## CellType filtering: at list cellTypeThrs * 100 % genes with expression (tpm>=1) 
  cellTypefilter=colSums( sc.tpm.coding.df  >=1)>= dim(sc.tpm.coding)[[1]]*cellTypeThrs
  filtered.sc.tpm.coding<- sc.tpm.coding.df[,cellTypefilter]     
  ## Gene filtering: at list geneThrs * 100 % of cells with expression (tpm>=1)  
  genefilter=rowSums( filtered.sc.tpm.coding[,-1]  >=1)>=   dim(filtered.sc.tpm.coding)[[2]]*geneThrs
  filtered.sc.tpm.coding<- filtered.sc.tpm.coding[genefilter, ]   
  
  sc.tpm.cod.ncbi <-  merge(filtered.sc.tpm.coding, unique(subset(rel_sym_ncbi,  select=c(ncbi, symbol))), by.x="gene", by.y="symbol")   
  sc.tpm.cod.ncbi <- subset(sc.tpm.cod.ncbi, select=-c(ncbi ))   
  
  # transpose matrix and compute z-scores
  sc.tpm.cod.ncbi.t <- sc.tpm.cod.ncbi 
  row.names(sc.tpm.cod.ncbi.t) <- sc.tpm.cod.ncbi.t[["gene"]]
  sc.tpm.cod.ncbi.t <- sc.tpm.cod.ncbi.t[,-1]
  sc.tpm.cod.ncbi.t <- t(sc.tpm.cod.ncbi.t)
  sc.zscore.cod.ncbi <- scale(sc.tpm.cod.ncbi.t)
  sc.zscore.cod.ncbi <- t(sc.zscore.cod.ncbi)
  sc.tpm.cod.ncbi <- t(sc.tpm.cod.ncbi.t)
  
  return(list(sc.tpm.cod.ncbi=sc.tpm.cod.ncbi,sc.zscore.cod.ncbi=sc.zscore.cod.ncbi))
}
create_zscore_table <- function(developmentEX.cells, sc.zscore.cod.ncbi, sc.tpm.cod.ncbi, sets.list, printDataFile=FALSE  ){
  selectedSignatures <- names(sets.list)[-1]
  devel.list <- list()
  for(dev in c("EarlyRadialGlia", "RadialGlia", "IPCs", "Transition",  "Newborn",  "Mature" )){ 
    selectedCells <- subset(developmentEX.cells,CellType==dev )$Cell
    cellsInDev <-  intersect(colnames(sc.zscore.cod.ncbi) , selectedCells) 
    devel.list[[dev]][["zscores"]] <- subset(sc.zscore.cod.ncbi, select=cellsInDev)
    devel.list[[dev]][["means"]] <- apply(devel.list[[dev]][["zscores"]], 1, mean) 
    devel.list[[dev]][["sd"]] <- apply(devel.list[[dev]][["zscores"]], 1, sd) 
    for(cl in  selectedSignatures ){  
      genesInClass <-  subset(  sets.list[[cl]], select=c("Symbol") )[[1]]
      devel.list[[dev]][[cl]][["z-means"]] <-  devel.list[[dev]][["means"]][ names(devel.list[[dev]][["means"]]) %in%  genesInClass] 
      devel.list[[dev]][[cl]][["mean"]] <- mean(devel.list[[dev]][[cl]][["z-means"]]) 
      devel.list[[dev]][[cl]][["sd"]] <- sd( devel.list[[dev]][[cl]][["z-means"]])
    }
  }
  tab.zscores <- data.frame()
  for(dev in c("EarlyRadialGlia", "RadialGlia", "IPCs",  "Transition",  "Newborn",  "Mature" )){
    for(cl in selectedSignatures ){
      tmp <-  as.data.frame(devel.list[[dev]][[cl]][["z-means"]])
      colnames(tmp) <- "zmeans"
      tmp$devel <- dev
      tmp$class <- cl
      tmp$gene <- row.names(tmp)
      tab.zscores <- rbind(tab.zscores, tmp)
    }
  }
  if(printDataFile){ print_Zscore_means_inCellTypes(devel.list) }
  return(tab.zscores)
}  
print_Zscore_means_inCellTypes <- function(devel.list, sfx){  
  tab.Intermediate.Zscores <- as.data.frame(  devel.list[["EarlyRadialGlia"]][["means"]] )
  names(tab.Intermediate.Zscores)<- "EarlyRadialGlia"
  tab.Intermediate.Zscores <- merge(tab.Intermediate.Zscores,   devel.list[["RadialGlia"]][["means"]],by="row.names" )
  names(tab.Intermediate.Zscores)[length(names(tab.Intermediate.Zscores))] <- "RadialGlia"
  tab.Intermediate.Zscores <- merge(tab.Intermediate.Zscores,   devel.list[["IPCs"]][["means"]],by.x="Row.names", by.y="row.names" )
  names(tab.Intermediate.Zscores)[length(names(tab.Intermediate.Zscores))] <- "IPCs"
  tab.Intermediate.Zscores <- merge(tab.Intermediate.Zscores,   devel.list[["Transition"]][["means"]],by.x="Row.names", by.y="row.names" )
  names(tab.Intermediate.Zscores)[length(names(tab.Intermediate.Zscores))] <- "Transition"
  tab.Intermediate.Zscores <- merge(tab.Intermediate.Zscores,   devel.list[["Newborn"]][["means"]],by.x="Row.names", by.y="row.names" )
  names(tab.Intermediate.Zscores)[length(names(tab.Intermediate.Zscores))] <- "Newborn"
  tab.Intermediate.Zscores <- merge(tab.Intermediate.Zscores,   devel.list[["Mature"]][["means"]],by.x="Row.names", by.y="row.names" )
  names(tab.Intermediate.Zscores)[length(names(tab.Intermediate.Zscores))] <- "Mature"
  names(tab.Intermediate.Zscores)[1] <- "Gene"
  write.csv( subset(tab.Intermediate.Zscores  ) , file =  paste(outDir,"/table_Zscore_means_inCellTypes.csv",sep=""), row.names = FALSE  )
  return(tab.Intermediate.Zscores)
}
############# END FUNCTIONS #############################

##### Directories & files ##### 
dirData <-  NowakowskyData_Folder
dirMAT <-   materials_Folder
outDir <-  output_Folder

programs_File <- paste(dirMAT,fileName_programs,sep="/")
nowakowski_exprMatrix_File<-paste(dirData,fileName_NowaExprMatrix,sep="/")
nowakowski_meta_File<-paste(dirData,fileName_NowaMeta,sep="/")
rel_sym_ncbi_File<- paste(dirMAT,fileName_human_gene,sep="/") 
##### ##### ##### ##### ##### ##### 

printOnFile <- TRUE
cellTypeThrs <- 0.05 # 5% threshold on cells
geneThrs <- 0.05     # 5% threshold on gene

data.list <- importData(nowakowski_exprMatrix_File, nowakowski_meta_File, programs_File,  rel_sym_ncbi_File  ) 
exprs.df.list <- filter_and_zscore(data.list$sc.tpm.coding,data.list$rel_sym_ncbi, cellTypeThrs, geneThrs) 
tab.zscores<- create_zscore_table(data.list$developmentEX.cells, exprs.df.list$sc.zscore.cod.ncbi, exprs.df.list$sc.tpm.cod.ncbi,data.list$sets.list, printOnFile )
 
