library(data.table) 

createBackground <- function(tpmFile=NULL, metaFile=NULL,   rel_sym_ncbi_File=NULL ){
  sc.tpm <- fread(tpmFile ) # 
  sc.meta <- read.csv(metaFile, header=T, as.is=T,sep="\t") # 
  ## define cell-type classes
  {
    MatureExcNeuron <- c("EN-PFC1", "EN-PFC2", "EN-PFC3", "EN-V1-1", "EN-V1-2", "EN-V1-3")  
    IPCs <- c("IPC-div1", "IPC-div2")  
    NewbornExcNeuron <- c("nEN-early1", "nEN-early2", "nEN-late")  
    NewbornMGENeuron <- c("nIN1", "nIN2","nIN3", "nIN4", "nIN5" )  
    RadialGlia <- c("RG-div1", "RG-div2", "oRG", "tRG", "vRG") 
    EarlyRadialGlia <- c("RG-early") 
    Transition <- c("IPC-nEN1", "IPC-nEN2", "IPC-nEN3")  
    
    sc.meta$development <- "none"
    sc.meta$development[sc.meta$WGCNAcluster %in% c(  EarlyRadialGlia )] <- "EarlyRadialGlia"
    sc.meta$development[sc.meta$WGCNAcluster %in% c(  IPCs,  RadialGlia )] <- "Progenitors"
    sc.meta$development[sc.meta$WGCNAcluster %in% c( Transition)] <- "Transition"
    sc.meta$development[sc.meta$WGCNAcluster %in% c( NewbornExcNeuron )] <- "Newborn"
    sc.meta$development[sc.meta$WGCNAcluster %in% c( MatureExcNeuron )] <- "Mature"
  }
  rel_sym_ncbi <- read.csv(rel_sym_ncbi_File, header=T, as.is=T, sep="\t")
  codingGenes <- subset(rel_sym_ncbi, type =="protein-coding")  
  
  sc.tpm.coding <- as.data.frame(subset(sc.tpm, gene %in% codingGenes$symbol) ) 
  
  newborn_developing.cells <- subset(sc.meta, development=="Newborn" |  development=="Mature")  
  
  sc.tpm.newborn_developing <- subset(sc.tpm, select=c("gene",newborn_developing.cells$Cell))
  sc.tpm.newborn_developing.coding <- as.data.frame(subset(sc.tpm.newborn_developing, gene %in% codingGenes$symbol) ) 
  row.names(sc.tpm.newborn_developing.coding) <- sc.tpm.newborn_developing.coding$gene
  sc.tpm.newborn_developing.coding <- subset(sc.tpm.newborn_developing.coding, select=-c(gene))
  
  notZeros <- sc.tpm.newborn_developing.coding[rowSums(sc.tpm.newborn_developing.coding[,  ])>0, ]   
  bkg.notZeros.coding <- unique( subset(rel_sym_ncbi,  symbol %in%   row.names(notZeros) )$ncbi )  
  return(bkg.notZeros.coding)
}
 