README
figure7_code.R
The script performs the analysis used to generate the plot in figure 7 as described in the Methods.
The script returns a DataFrame object containing the average normalised expression score for each gene (values used in the figure 7). Moreover, if the flag printOnFile is TRUE, a file in csv format (named table_Zscore_means_inCellTypes.csv) with the same values will be generated. cellTypeThrs and geneThrs, set to 0.05, represent the 5% threshold used to filter genes and cells as described in the methods.

The input files used for the script are: 
programs_File is the name of file containing the program gene sets. The file is in MAGMA format and the genes are identified by using ncbi-ids.
nowakowski_exprMatrix_File is the name of file containing the expression matrix of the Nowakowsky dataset.
nowakowski_meta_File is the name of file containing the metadata of the Nowakowsky dataset.
rel_sym_ncbi_File is the name of file containing the associations symbols-ncbi id and the gene biotype. This file has to contain 3 columns:
1) ‘ncbi’, containing the ncbi ids.
2) ‘symbol’ containing the symbol ids.
3)  ‘type’  containing the gene biotype. 

ExtractBackground.R
This function is used to generate the background containing all genes with non-zero expression in at least one Newborn or Developing cell (Ngene = 16,431).
The function requires as input:
1) the file containing the expression matrix of the Nowakowsky dataset.
2) the file containing the metadata of the Nowakowsky dataset.
3)  file containing the associations symbols-entrez id and the gene biotype. This file is used to select the protein coding genes and it has the same format as the file rel_sym_ncbi_File used in the figure7_code.R.

DE_analysis_code.R
The script performs the Differential Expression Analysis between WT and KO samples for each time-points and the Differential Expression Analysis comparing successive pair of time-points in WT.
The script returns:
- a list (res_KO_v_WT.df.list) of DataFrame objects (one for each time-point) containing the results for the KO vs WT comparisons.
-  a list (res_WT_v_WT.df.list) of DataFrame objects (one for each successive pair of time-points) containing the results for the WT vs WT comparisons.
The DataFrame objects contain the columns:baseMean,log2FoldChange,lfcSE,stat,pvalue, and padj, as computed by DESeq2 results function. They also include a column p_bonf containing the Bonferroni-corrected-pvalues used  for the further analyses. 

The input files used for the script are: 
- gtf is the name of file containing the  gencode.v31 primary assembly annotation in gtf format.
- samps is the name of file containing the meta data for the samples (file “samples_meta.csv")
- ENS_biotype is the name of file containing the gene biotype from gencode v31 primary annotation. The first 2 columns of this file have to contain: 1) ENSEMBLE_ID; 2) Biotype.
