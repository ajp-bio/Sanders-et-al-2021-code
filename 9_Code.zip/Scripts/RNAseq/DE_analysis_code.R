library(tximport) 
library(GenomicFeatures)
library(plyr) 
library(DESeq2)
library(gtools)
library(edgeR)
library(limma)

#### Set directories and import files
dir <- data_folder
dirRSEM <- RSEM_folder
dirGen<- annotation_FOlder
dirOut <- output_Folder
##### import gencode annotation
gtf <- paste(dirGen,"/gencode.v31.primary_assembly.annotation.gtf",sep="")
samps <- read.csv(paste(dir, "/samples_meta.csv", sep="") )
## GENES association SYMBOL-NCBI
ENS_biotype <- read.csv(paste(dirGen,fileName_human_gene,sep="/"), header=F, as.is=T,sep="\t") # 
names(ENS_biotype) <- c("ENS", "Type" )
codingGenes <- subset(ENS_biotype, Type =="protein_coding") 

files <- file.path(dirRSEM,paste0(samps$sample_id,"_quant.genes.results"))
names(files) <- c(paste0("s_",samps$sample_id) ) 

### DESeq2 analysis on   KO1 + KO2 vs WT for each timepoint 
res_KO_v_WT.df.list <- list()
for( time in c("15", "20","30", "60" ) ){
  samps.time <- samps[samps$time==time, ]
  txi.rsem.genes <- tximport( files[names(files) %in% samps[samps$time==time,c("name")] ] , type = "rsem", txIn = FALSE, txOut = FALSE)
  txi.rsem.genes$length[txi.rsem.genes$length == 0] <- 1
  
  sampleTable  <- data.frame(	 	 
    sample = samps.time[["sample_id"]],		 
    genotype = samps.time[["genotype"]],	 	 
    time =  samps.time[["time"]],
    line =  samps.time[["line"]])	
  
  sampleTable$time <- factor( sampleTable$time)
  rownames(sampleTable) <- colnames(txi.rsem.genes$counts)
  
  sampleTable$genotype <- factor( sampleTable$genotype, levels = c("wt", "ko")) 
  dds <- DESeqDataSetFromTximport(txi.rsem.genes, sampleTable, ~genotype )
  # Create DESeq object
  dds <- DESeq(dds)
  ## Gene filtering: at list 3 samples with expression >0 (in this case I used the cpm but it is the same with counts)
  filter=rowSums(cpm(txi.rsem.genes$counts)>=1)>= dim(sampleTable)[[1]]*1/3
  filtered_matrix=txi.rsem.genes$counts[filter,]
  ### Filtering on coding genes
  genes_To_Use <- intersect(codingGenes$ENS,row.names(filtered_matrix))
  dds <-  dds[  rownames(dds ) %in% genes_To_Use, ]
  ### DESeq2 analysis
  res <- DESeq2::results(dds)
  res_KO_v_WT.df.list[[time]] <- as.data.frame(res )
  res_KO_v_WT.df.list[[time]]$p_bonf <- p.adjust(res_KO_v_WT.df.list[[time]]$pvalue, method = "bonferroni")
}

### DESeq2 analysis comparing successive pair of timepoints in WT
combs <- combinations(n=4,r=2,v=c("15", "20","30", "60" ),repeats.allowed=FALSE,set=TRUE)
res_WT_v_WT.df.list <- list()
for( idx in c(1:dim(combs)[[1]] ) ){
  time <- paste("wt", combs[idx,1] ,  combs[idx,2],sep="_") 

  samps.time <- samps[samps$genotype=="wt" &  samps$time %in% combs[idx,] , ]
  txi.rsem.genes <- tximport( files[names(files) %in%  samps.time[,c("name")] ] , type = "rsem", txIn = FALSE, txOut = FALSE)
  txi.rsem.genes$length[txi.rsem.genes$length == 0] <- 1
  
  sampleTable  <- data.frame(	 	 
    sample = samps.time[["sample_id"]],		 
    genotype = samps.time[["genotype"]],	 	 
    time =  samps.time[["time"]],
    line =  samps.time[["line"]])	
  
  sampleTable$time <- factor(sampleTable$time)
  rownames(sampleTable) <- colnames(txi.rsem.genes$counts)
  dds <- DESeqDataSetFromTximport(txi.rsem.genes, sampleTable, ~time )
  
  # Create DESeq object
  dds <- DESeq(dds)
  ## Gene filtering: at list 3 samples with expression >0 (in this case I used the cpm but it is the same with counts)
  filter=rowSums(cpm(txi.rsem.genes$counts)>=1)>= dim(sampleTable)[[1]]*1/3
  filtered_matrix=txi.rsem.genes$counts[filter,]
  ### Filtering on coding genes
  genes_To_Use <- intersect(codingGenes$ENS,row.names(filtered_matrix))
  dds<-  dds[  rownames(dds ) %in% genes_To_Use, ]
  ### DESeq2 analysis
  res <- DESeq2::results(dds)
  res_WT_v_WT.df.list[[time]] <- as.data.frame(res )
  res_WT_v_WT.df.list[[time]]$p_bonf <- p.adjust(res_WT_v_WT.df.list[[time]]$pvalue, method = "bonferroni")
}

