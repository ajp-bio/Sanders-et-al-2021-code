#!/usr/bin/Rscript
#################################################################################################
#denovo_snv_rate_ratio_test.R
#################################################################################################
#De novo SNV competitive enrichment test using Poisson rate ratio test
#Andrew Pocklington
#V0.1 13/03/2019

#Competitive gene-set enrichment test for SNVs. Tests whether ratio of observed to expected rate of de novo mutations differs between two sets of genes. Can be used to test for differential enrichment between 2 gene-sets or between one gene-set and the background set of all other genes for which mutation rate data is available

#NOTE: gene-sets don't strictly have to be independent, but test will be over-conservative if they overlap [Think this still holds...]. By default, any overlapping genes are removed from the background/comparator set; set --indep flag to FALSE to perform test without removing overlapping genes

#Required parameters:

#--mut_path: Path to file containing mutation rate data

#--denovo_path: Path to file containing de novo rare variant data

#--ann_path: Path to file containing gene sets

#--dest_path: Path to output file for results

#Optional parameters:

#--class: Mutation classes to be analysed [default = NS,LoF; other = syn, mis, non, splice, frameshift, inframe, mis_inframe]

#--ann_format: Format of annotation file [default = standard; other = magma. NOTE: this doesn't recognise all files that can be read into MAGMA, just a specific MAGMA-compatible format: 2 tab-delimited columns (no header, 1 line per gene-set) with field 1 = annotation name & field 2 = space-separated list of entrez gene ids]

#--base_set: Background/comparator set [default is to compare each gene-set to all genes for which mutation rate data is available; other = name of comparator gene-set]

#--base_path: Path to file containing background/comparator set. Only used if --base_set specified. [default = ann_path. NOTE: file format always assumed to be same as for ann_path]

#--indep: When --base_set specified, is the background set to be made completely independent of the gene-set being tested (by removing any overlapping genes from the background when each set is tested) [default = TRUE]

#--alt: Alternative hypothesis [default = two.sided (gene-set de novo enrichment factor different from that of comparator set); other = greater or less]

#--X_seq: Has X chromosome been sequenced [default is to work this out from the de novo rare variant data]

#--Y_seq: Has Y chromosome been sequenced [default is to work this out from the de novo rare variant data]

####################################################################################
#e.g.

#cd "/Users/andrew/Projects (active)/2019/synapse networks/code/snv/"

#Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/genetics/mutation rates/2017/processed/probTable_gencode_reannotatedIDs.txt' --denovo_path '/Users/andrew/Data/genetics/rare variants/schizophrenia/combined/2017/processed/DeNovo_counts_ExomeOnly_summarised.txt' --ann_path '/Users/andrew/Projects (active)/2019/synapse networks/data/ann/NRC/NRC_clusters_standard_format.txt' --dest_path default_dest_path = '/Users/andrew/Projects (active)/2019/synapse networks/processed/snv/NRC_clusters' --ann_format standard --base_set NMDAR_network --base_path '/Users/andrew/Projects (active)/2018/methodology/SNV/data/ann/NRC_and_PSD_clusters_standard_format.txt' --indep FALSE --alt greater --X_seq TRUE --Y_seq F --class NS,LoF,mis_inframe
####################################################################################
#work
#source('/Users/andrew/Projects (active)/2019/synapse networks/code/snv/denovo_snv_rate_ratio_test.R')
####################################################################################
#required libraries
library(optparse)
suppressMessages(library(data.table))
#######################################################################
# options - default
#######################################################################
#### mutation data ####

#mutation rate data
#default_mut_path = '/Users/andrew/Data/genetics/mutation rates/2017/processed/probTable_gencode_reannotatedIDs.txt'
default_mut_path = NA

#de novo rare variant data
#default_denovo_path = '/Users/andrew/Data/genetics/rare variants/schizophrenia/combined/2017/processed/DeNovo_counts_ExomeOnly_summarised.txt'
default_denovo_path = NA

#mutation classes to be analysed
default_mut_class = 'NS,LoF'

#sex chromosomes sequenced (default is to try & work this out from the de novo data provided)
default_X_seq = NA
default_Y_seq = NA

#########################
#### annotation data ####

#default annotation data
#default_ann_path = '/Users/andrew/Projects (active)/2019/synapse networks/data/ann/NRC/NRC_clusters_standard_format.txt'
default_ann_path = NA

#default annotation format
default_ann_format = 'standard' #format of annotation file ('standard', or 'magma')

###################################
#### background/comparator set ####

#is background/comparator to be made independent of gene-set tested
default_indep = TRUE

#default background/comparator set
default_base_set = NA
default_base_path = NA

########################################################
#### hypothesis tested (two-sided, greater or less) ####
default_alt = 'two.sided'
#########################
#########output #########

#results file
#default_dest_path = '/Users/andrew/Projects (active)/2019/synapse networks/processed/snv/NRC_clusters'
default_dest_path = NA

#######################################################################
# other variables
#######################################################################

#classes of mutations that can be analysed: basic types = syn, mis, non, splice, frameshift, inframe
#                                        compound types = mis_inframe, NS, LoF
all_mut_class = list('syn' = c('syn'), 'mis' = c('mis'), 'non' = c('non'), 'splice' = c('splice'), 'frameshift' = c('frameshift'), 'inframe' = c('inframe'),'mis_inframe' = c('mis','inframe'), 'NS' = c('mis','non','splice','frameshift','inframe'), 'LoF' = c('non','splice','frameshift'))

###########################################################################
# option settings
###########################################################################
option_list = list(
make_option("--mut_path", action="store", default=default_mut_path, type='character',
	help="Path to file containing mutation rate data [required]"),
make_option("--denovo_path", action="store", default=default_denovo_path, type='character',
	help="Path to file containing de novo rare variant data [required]"),
make_option("--ann_path", action="store", default=default_ann_path, type='character',
	help="Path to file containing gene sets [required]"),
make_option("--dest_path", action="store", default=default_dest_path, type='character',
	help="Path to output file for results [required]"),
make_option("--class", action="store", default=default_mut_class, type='character',
	help="Mutation classes to be analysed [default = NS, LoF; other = syn, mis, non, splice, frameshift, inframe, mis_inframe]"),
make_option("--ann_format", action="store", default= default_ann_format, type='character',
	help="Format of annotation file [default = standard; other = magma. NOTE: this doesn't recognise all files that can be read into MAGMA, just a specific MAGMA-compatible format: 2 tab-delimited columns (no header, 1 line per gene-set) with field 1 = annotation name & field 2 = space-separated list of entrez gene ids]"),
make_option("--base_set", action="store", default=default_base_set, type='character',
	help="Background/comparator set [default is to compare each gene-set to all genes for which mutation rate data is available; other = name of comparator gene-set]"),
make_option("--base_path", action="store", default=default_base_path, type='character',
	help="Path to file containing background/comparator set. Only used if --base_set specified. [default = ann_path. NOTE: file format always assumed to be same as for ann_path]"),
make_option("--indep", action="store", default=default_indep, type='logical',
	help="When --base_set specified, is the background set to be made completely independent of the gene-set being tested (by removing any overlapping genes from the background when each set is tested) [default = TRUE]"),
make_option("--alt", action="store", default=default_alt, type='character',
	help="Alternative hypothesis [default = two.sided (gene-set de novo enrichment factor different from that of comparator set); other = greater or less]"),
make_option("--X_seq", action="store", default=default_X_seq, type='logical',
	help="Has X chromosome been sequenced [default is to work this out from the de novo rare variant data]"),
make_option("--Y_seq", action="store", default=default_Y_seq, type='logical',
	help="Has Y chromosome been sequenced [default is to work this out from the de novo rare variant data]")
)

#######################################################################
# functions
#######################################################################
#read mutation rate data
read_mut_rate <- function(mut_path,mut_class) {
	
	#read table of raw data
	#note: since entrez ids are all numeric, blank ids ('') are converted to NA in 'ncbi' field
	#      this does not happen in chromosome ('chr') field, as it contains both strings and numbers ('1', 'X', ...)
	tmp = fread(mut_path)
	
	#calculate mutation rate per gene for each class: sum of mutation rates for constituent basic types
	for (next_class in names(mut_class)) {
		
		tmp[[next_class]] = rowSums(subset(tmp,select = mut_class[[next_class]]),na.rm = TRUE);
	}
	
	#only return data for genes with both gene id and chromosome specified
	remove_chr = c('')
	
	#return class mutation rate data
	subset(tmp,!(is.na(ncbi) | (chr %in% remove_chr)),select = c('ncbi','chr',names(mut_class)))
	
}

###########################################################################
#read de novo rare variant data
read_denovo_data <- function(denovo_path,mut_class) {
	
	#read table of raw data
	tmp = fread(denovo_path)
	
	#count number of mutations per gene for each class: sum of mutation counts for constituent basic types
	for (next_class in names(mut_class)) {
		
		tmp[[next_class]] = rowSums(subset(tmp,select = mut_class[[next_class]]),na.rm = TRUE)
	}
	
	#return class denovo count data for all genes with a gene id
	subset(tmp,!(is.na(ncbi)),select = c('ncbi',names(mut_class)));
	
}

###########################################################################
#read number of male & female trios from header of denovo file
read_trio_N <- function(denovo_path) {
	
	tmp_header = scan(denovo_path,what = list('','',1),nlines = 3,comment.char = '')
	
	n_male = tmp_header[[3]][which(tmp_header[[1]] == '#N_trios_male')]
	n_female = tmp_header[[3]][which(tmp_header[[1]] == '#N_trios_female')]
	
	list('all' = n_male + n_female,'M' = n_male,'F' = n_female)
}

###########################################################################
#calculated expected number of mutations for each gene & combine with observed and rate data
calculate_expected <- function(denovo_data,mut_rate,mut_names,trio_N) {
	
	###########################################################################
	#calculate number of gene copies in males & females for each sex chromosome
	#X    = 1 in males, 2 in females
	#X|XY = 1 in males, 2 in females (X chr genes in pseudo autosomal region (so also found on Y))
	#Y    = 1 in males, 0 in females
	
	#initialise sex chromosome gene counts
	sex_chr_N = list('X' = list('M' = 0,'F' = 0),'Y' = list('M' = 0,'F' = 0), 'X|XY' = list('M' = 0,'F' = 0))
	
	#collate list of chromosomes for genes with de novos
	denovo_chr = unique(subset(mut_rate,ncbi %in% denovo_data$ncbi)$chr)
	
	#check if X chromosome sequenced
	if(is.na(opt$X_seq)){
		
		X_seq = 'X' %in%  denovo_chr
		
		#write to log
		cat('Checking de novo data... X chromosome sequenced =', X_seq,'\n\n')
		
	}else{X_seq = opt$X_seq}
	
	#check if Y chromosome sequenced
	if(is.na(opt$Y_seq)){
		
		Y_seq = 'Y' %in%  denovo_chr
		
		#write to log
		cat('Checking de novo data... Y chromosome sequenced =', Y_seq,'\n\n')
		
	}else{Y_seq = opt$Y_seq}
	
	#if X chromosome sequenced
	if(X_seq) {
		
		sex_chr_N[['X']] = list('M' = 1,'F' = 2)
		sex_chr_N[['X|XY']] = list('M' = 1,'F' = 2)
	}
	#if Y chromosome sequenced
	if(Y_seq) {
	
		sex_chr_N[['Y']][['M']] = 1;
		sex_chr_N[['X|XY']][['M']] = sex_chr_N[['X|XY']][['M']] + 1
	}
		
	##################################################################################
	#calculate number of copies of each gene in dataset (autosomal genes: 2 x N trios)
	gene_count = rep.int(2*trio_N[['all']],dim(mut_rate)[1])
	
	#adjust counts for genes on sex chromosomes
	for (next_chr in names(sex_chr_N)) {
		
		chr_count = sex_chr_N[[next_chr]]
		
		gene_count[which(mut_rate[['chr']] == next_chr)] = (chr_count[['M']]*trio_N[['M']] + chr_count[['F']]*trio_N[['F']])
		
	}
	
	#initialise variable to hold expected mutation counts
	mut_expected = subset(mut_rate,select = ncbi)
	
	#calculate expected number of mutations per gene for each class: gene mutation rate for class x number of gene copies
	for (next_class in mut_names) {
		
		mut_expected[[next_class]] = mut_rate[[next_class]]*gene_count

	}
	##################################################################################
	#combine mutation rate, expected & count data
	tmp = merge(mut_rate,mut_expected,by = 'ncbi',suffixes = c('','_expected'),all.x = TRUE)
	
	mut_rate_denovo = merge(tmp,denovo_data,by = 'ncbi',suffixes = c('','_count'),all.x = TRUE)
	
	return(mut_rate_denovo)
	
}
###########################################################################
#read gene annotations from 'standard' format file: tab-delimited, 2 required fields ('ann','ncbi'), 1 line per gene-set
#                                                   may have additional fields (e.g., 'ann_id','symbol')
#'ann' field = annotation name
#'ncbi' field = pipe ('|') separated list of entrez gene ids
#'symbol' field = pipe ('|') separated list of gene symbols (symbol field not used here)
#order of genes in ncbi & symbol field (if present) must be the same
# e.g.
#ann	ncbi	symbol
#ann_name1	entrez1|entrez2|...	symbol1|symbol2|...
#ann_name2...
read_standard <- function(next_path) {
	
	tmp <- fread(next_path)
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],'|',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}
###########################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','ncbi'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}

#read annotations
read_ann <- function(next_path,format) {
	
	switch(format,
	
		'standard' = read_standard(next_path),
		'magma' = read_MAGMA(next_path)
	)
	
}



#summarise set of genes: N gene, N denovos observed & observed/expected ratio (for each class of mutation)
set_summary <- function(set_data,mut_names,obs_fields,exp_fields) {
	
	N_gene = dim(set_data)[1]
	
	mut_sums = colSums(set_data,na.rm = TRUE)
	
	tmp = lapply(mut_names,function(k) c(mut_sums[[obs_fields[[k]]]],mut_sums[[exp_fields[[k]]]]))
	
	c(N_gene,unlist(tmp))
	
}


#Return P + [set & background): N gene; N observed, N expected (set & comparator), rate ratio, 95%CI, p-value
test_classes <-function(ann_vals,comparator_vals,mut_names,alt) {
	
	ann_N = ann_vals[1] #N gene
	comparator_N = comparator_vals[1] #N gene
	
	tmp = lapply((1:length(mut_names)),function(k) differential_test(ann_vals[2*k],ann_vals[2*k + 1],comparator_vals[2*k],comparator_vals[2*k+1],alt))
	
	c(ann_N,comparator_N,unlist(tmp))
}

#Test for difference in ratio of observed (X,Y) to expected (P,Q)
differential_test <- function(X,P,Y,Q,alt) {
	
	t = poisson.test(x = c(X,Y), T = c(P,Q), alternative = alt)
	
	mapply(function(k) signif(k,3),c(X,P,Y,Q,t$estimate,t$conf.int,t$p.value))
}
###########################################################################
#initialisation
###########################################################################
#start time
start.time = Sys.time()

#variables
opt = parse_args(OptionParser(option_list=option_list))

#log file
log_path = paste(opt$dest_path,'.log',sep='')
sink(file = log_path, append = F)
cat('##################################################################
#De novo SNV competitive enrichment test using Poisson rate ratio test
#Andrew Pocklington
#V0.1 13/03/2019
##################################################################\n')
print(opt)
cat('Analysis started at',as.character(start.time),'\n\n')
#########################################################################################################################################
# main - start
#########################################################################################################################################
### Expected gene mutation rates ###

#read mutation rate data and calculate per-gene mutation rates for each class of mutation required 
mut_names = unlist(strsplit(opt$class,',',fixed = TRUE))
mut_class = all_mut_class[mut_names]

mut_rate = read_mut_rate(opt$mut_path,mut_class)

#write summary to log
cat('Mutation rate data read from file:',opt$mut_path,'\n')
cat('Rates calculated for mutation classes:',names(mut_class),'\n')
cat('N gene =',dim(mut_rate)[1],'\n\n')
#########################################################################################################
### Observed denovo mutations ###

#read denovo mutation data and calculate observed per-gene N mutation for each class of mutation required
denovo_data = read_denovo_data(opt$denovo_path,mut_class)

#read number of male & female trios from header of denovo file
trio_N = read_trio_N(opt$denovo_path)

#calculated expected number of mutations for each gene & combine with observed de novo counts
mut_rate_denovo = calculate_expected(denovo_data,mut_rate,mut_names,trio_N)

#write summary to log
cat('De novo data read from file:',opt$denovo_path,'\n')
cat('Observed N mutation calculated for mutation classes:',names(mut_class),'\n')
cat('N gene with 1 or more observed mutation =',dim(denovo_data)[1],'\n')
cat('N trio:',trio_N[['M']],'male,',trio_N[['F']],'female\n\n')

#clear up intermmediate variables
rm(mut_rate,denovo_data)
#########################################################################################################
### Gene sets (annotations & background/comparator set) ###

#read annotation gene sets
ann_data = read_ann(opt$ann_path,opt$ann_format)

#write summary to log
cat(length(ann_data),'annotations read from file:',opt$ann_path,'\n\n')
############################
#read/extract comparator set

#if base_path not specified
if(is.na(opt$base_path)) {
	
	#if base_set not specified
	if(is.na(opt$base_set)) {
		
		#set comparator to all genes for which de novo rates are available
		comparator = mut_rate_denovo$ncbi
		
		cat('All genes with de novo rates available used to define background/comparator set\n\n')
	}
	else {#otherwise, extract (& remove) comparator set from ann_data
		
		comparator = ann_data[[opt$base_set]]
		tmp = ann_data[setdiff(names(ann_data),c(opt$base_set))]
		ann_data = tmp
		
		cat('Background/comparator set:',opt$base_set,'\nExtracted from annotation file\n\n')
	}	
} else {#if base_path specified
	
	#if base_set not specified, raise an error
	if(is.na(opt$base_set)) {stop('--base_set must be specified if --base_path specified')
	}
	else{#otherwise, read file and extract comparator set
		
		comparator = read_ann(opt$base_path,opt$ann_format)[[opt$base_set]]
		
		cat('Background/comparator set:',opt$base_set,'\nRead from file:',opt$base_path,'\n\n')
	}
	
}
#########################################################################################################
init.time <- Sys.time()
#########################################################################################################
### Analysis ###

#Columns to be selected when calculating observed/expected
obs_fields = lapply(mut_names,function(k) c(paste(k,'_count',sep='')))
names(obs_fields) = mut_names

exp_fields = lapply(mut_names,function(k) c(paste(k,'_expected',sep='')))
names(exp_fields) = mut_names

select_cols = c(unlist(obs_fields),unlist(exp_fields))

#Calculate number of genes & number of denovos observed (X) & expected (P) in each gene-set
ann_summary = mapply(function(k) set_summary(subset(mut_rate_denovo,ncbi %in% ann_data[[k]],select = select_cols), mut_names,obs_fields,exp_fields),names(ann_data))

#if comparator is independent of gene-set (i.e. indep = TRUE)
if(opt$indep) {
	
	cat('Making background set completely independent of gene-set being tested...\n\n')
	
	#Extract subset of data for genes in comparator set
	comparator_data = subset(mut_rate_denovo,ncbi %in% comparator)
		
	#Calculate number of genes & number of denovos observed (Y) & expected (Q) in each comparator set 
	comparator_summary = mapply(function(k) set_summary(subset(comparator_data,!(ncbi %in% ann_data[[k]]),select = select_cols),mut_names,obs_fields,exp_fields),names(ann_data))
	
	#test each gene-set
	results = data.table(t(mapply(function(k) test_classes(ann_summary[,k],comparator_summary[,k],mut_names,opt$alt),names(ann_data))),keep.rownames = TRUE)
	
} else {#if comparator is a fixed, single gene-set
	
	comparator_summary = set_summary(subset(mut_rate_denovo,ncbi %in% comparator,select = select_cols),mut_names,obs_fields,exp_fields)
	
	#test each gene-set
	results = data.table(t(mapply(function(k) test_classes(ann_summary[,k],comparator_summary,mut_names,opt$alt),names(ann_data))),keep.rownames = TRUE)
	
}

################
#set field names
class_fields = c('observed','expected','bkgd_observed','bkgd_expected','rate_ratio','lower_95','upper_95','P')
names(results) = c('ann','ann_N','bkgd_N',unlist(lapply(mut_names,function(k) mapply(function(f) paste(k,f,sep='_'),class_fields))))

#save results to file
write.table(results,file = paste(opt$dest_path,'.txt',sep=''),row.names = FALSE,col.names = TRUE,sep = '\t',quote = FALSE)

#########################################################################################################################################
#main - end
#########################################################################################################################################
end.time <- Sys.time()

init.time.taken = init.time - start.time
analysis.time.taken <- end.time - init.time

set_N = length(ann_data)
estimate_N = 10000
estimate.time.taken = analysis.time.taken*estimate_N/set_N

cat('Initialisation time =', init.time.taken,attr(init.time.taken, 'units'),'\n')
cat('Analysis of',set_N,' gene sets: time taken =',analysis.time.taken,attr(analysis.time.taken, 'units'),'\n')
cat('Estimated analysis time for',estimate_N,'gene sets =',estimate.time.taken,attr(estimate.time.taken, 'units'))
##############################
#stop sending data to log file
sink()