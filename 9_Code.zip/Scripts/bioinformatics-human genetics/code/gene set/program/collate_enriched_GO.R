#!/usr/bin/Rscript

#work
#source('.../code/gene set/program/collate_enriched_GO.R')

#################################################################################
#required libraries
suppressMessages(library(data.table))
library(Matrix)
#######################################################################
# Variables
#######################################################################
root_dir = ".../"

set_dir = paste(root_dir,'working/gene set/program/',sep='')
GO_test_dir = paste(root_dir,'processed/functional/GO/program/',sep='')
####################
#input

set_path = paste(set_dir,'program.txt',sep='')

#annotation gene-sets
GO_path = paste(root_dir,'working/gene set/GO/GO_strict_coding_20_2000.txt',sep='')

set_refined_path = list('early_increasing_ko' = paste(GO_test_dir,'increasing/early_increasing_ko_refined.txt',sep=''),'early_stable_ko' = paste(GO_test_dir,'stable/early_stable_ko_refined.txt',sep=''),'early_transient_ko' = paste(GO_test_dir,'transient/early_transient_ko_refined.txt',sep=''))

####################
#output

#log file
log_path = paste(root_dir,'code/gene set/program/log/collate_enriched_GO.log',sep='')

set_out_path = list('early_increasing_ko' = paste(set_dir,'functional/increasing_ko_GO.txt',sep=''),'early_stable_ko' = paste(set_dir,'functional/stable_ko_GO.txt',sep=''),'early_transient_ko' = paste(set_dir,'functional/transient_ko_GO.txt',sep=''))

######################
#other
set_names = c('early_increasing_ko','early_stable_ko','early_transient_ko')
#######################################################################
# functions
#######################################################################
#read expression data from file
read_expr_data <- function(next_path) {
	
	#read data into table
	tmp <- fread(next_path)
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],'|',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}

###########################################################################
#read gene annotations from 'standard' format file: tab-delimited, 2 required fields ('ann','ncbi'), 1 line per gene-set
#                                                   may have additional fields (e.g., 'ann_id','symbol')
#'ann' field = annotation name
#'ncbi' field = pipe ('|') separated list of ncbi/entrez gene ids
#'symbol' field = pipe ('|') separated list of gene symbols (symbol field not used here)
#order of genes in ncbi & symbol field (if present) must be the same
# e.g.
#ann	ncbi	symbol
#ann_name1	entrez1|entrez2|...	symbol1|symbol2|...
#ann_name2...
read_standard <- function(next_path) {
	
	tmp <- fread(next_path)
	
	#extract genes for each annotation
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],'|',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}
###########################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of ncbi/entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','ncbi'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}

########################################################################################
#extract overlap with downregulated genes & these save gene-sets (& covariates) to file
write_MAGMA <- function(path,data) {
	
	entrez_ids = mapply(function(k) paste(data[[k]],sep='',collapse = ' '),names(data))
	
	magma_table = data.table(ann = names(data), entrez = entrez_ids)
	
	write.table(magma_table,file = path,row.names = FALSE,col.names = FALSE,sep = '\t',quote = FALSE)
	
	cat('Gene sets written to file',path,'\n\n')
}

##########################################################################
#initialisation
###########################################################################
#log file
sink(file = log_path, append = F)
#########################################################################################################################################
# main - start
#########################################################################################################################################
#read GO gene-sets
GO_data = read_standard(GO_path)

#read program gene-sets - need all expressed as covariate
program_data = read_MAGMA(set_path)
	
cat(length(program_data),'gene-sets read from file: ',set_path,'\n\n')
for (next_ann in names(program_data)) {
	
	cat(next_ann,length(program_data[[next_ann]]),'\n')
}
cat('\n')

#############
#for each set
for (next_set in set_names) {
	
	#extract covariate gene-sets
	collated_data = list('expressed' = program_data$expressed)
	collated_data[[next_set]] = program_data[[next_set]]
	
	#########################################
	#read identifiers of enriched annotations
	GO_names = fread(set_refined_path[[next_set]])$ann

	#extract overlap with down-regulated genes
	for (name in GO_names) {
	
		collated_data[[name]] = intersect(GO_data[[name]],program_data[[next_set]])
	}

	cat(length(collated_data),'gene-sets collated:\n')
	for (next_ann in names(collated_data)) {
	
		cat(next_ann,length(collated_data[[next_ann]]),'\n')
	}
	cat('\n')

	#save these gene-sets (&) to file
	write_MAGMA(set_out_path[[next_set]],collated_data)	
}

##############################
#stop sending data to log file
sink()