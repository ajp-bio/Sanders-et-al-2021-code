#!/usr/bin/Rscript

#work
#source('.../code/gene set/program/collate_alt_expressed_sets.R')


#################################################################################
#required libraries
suppressMessages(library(data.table))
library(Matrix)
#######################################################################
# Variables
#######################################################################
root_dir = ".../"

data_dir = paste(root_dir,'working/gene set/',sep='')
####################
#input
nowa_path = paste(data_dir,'foetal/excitatory_newborn_developing_expressed.txt',sep='')
program_path = paste(data_dir,'program/program.txt',sep='')
####################
#output

collated_non_zero_path = paste(data_dir,'program/alt_expressed_non_zero.txt',sep='')
collated_filtered_path = paste(data_dir,'program/alt_expressed_filtered_5_percent.txt',sep='')

#log file
log_path = paste(root_dir,'code/gene set/program/log/collate_alt_expressed_sets.log',sep='')

####################
#other

nowa_names = c('ex_newborn_developing_non_zero','ex_newborn_developing_filtered_5_percent')
program_names = c('expressed','early_increasing_ko','early_stable_ko','early_transient_ko')
#######################################################################
# functions
#######################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','entrez'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,entrez],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}
########################################################################################
#extract overlap with downregulated genes & these save gene-sets (& covariates) to file
write_MAGMA <- function(path,data) {
	
	entrez_ids = mapply(function(k) paste(data[[k]],sep='',collapse = ' '),names(data))
	
	magma_table = data.table(ann = names(data), entrez = entrez_ids)
	
	write.table(magma_table,file = path,row.names = FALSE,col.names = FALSE,sep = '\t',quote = FALSE)
	
	cat('Writing gene sets to file',path,'\n\n')
}

##########################################################################
#initialisation
###########################################################################
#log file
sink(file = log_path, append = F)
#########################################################################################################################################
# main - start
#########################################################################################################################################

#read data files & extract gene sets
nowa_sets = read_MAGMA(nowa_path)[nowa_names]
program_sets = read_MAGMA(program_path)[program_names]

cat(length(nowa_sets),'in vivo expression gene-sets read:\n\n')
for (k in names(nowa_sets)) { cat(length(nowa_sets[[k]]),'\t',k,'\n')}
cat('\n')

cat(length(program_sets),'in vitro expression gene-sets read:\n\n')
for (k in names(program_sets)) { cat(length(program_sets[[k]]),'\t',k,'\n')}
cat('\n')

#collate gnee-sets for analysis
collated_non_zero_data = list('expressed' = nowa_sets$ex_newborn_developing_non_zero,'in_vitro_expressed' = program_sets$expressed,'early_increasing_ko' = program_sets$early_increasing_ko,'early_stable_ko' = program_sets$early_stable_ko,'early_transient_ko' = program_sets$early_transient_ko)

collated_filtered_data = list('expressed' = nowa_sets$ex_newborn_developing_filtered_5_percent,'in_vitro_expressed' = program_sets$expressed,'early_increasing_ko' = program_sets$early_increasing_ko,'early_stable_ko' = program_sets$early_stable_ko,'early_transient_ko' = program_sets$early_transient_ko)

#save gene-sets for analysis
write_MAGMA(collated_non_zero_path,collated_non_zero_data)
write_MAGMA(collated_filtered_path,collated_filtered_data)

cat('Gene-sets written to file:', collated_non_zero_path,'\n\n')
for (k in names(collated_non_zero_data)) { cat(length(collated_non_zero_data[[k]]),k,'\n')}
cat('\n')

cat('Gene-sets written to file:', collated_filtered_path,'\n\n')
for (k in names(collated_filtered_data)) { cat(length(collated_filtered_data[[k]]),k,'\n')}
cat('\n')
##############################
#stop sending data to log file
sink()