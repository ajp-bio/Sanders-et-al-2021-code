#!/usr/bin/Rscript

#work
#source('.../code/gene set/LoFi/LoFi_program_partition.R')

#################################################################################
#required libraries
suppressMessages(library(data.table))
library(Matrix)
#######################################################################
# Variables
#######################################################################
root_dir = ".../"

program_dir = paste(root_dir,'working/gene set/program/',sep='')
LoFi_dir = paste(root_dir,'working/gene set/LoFi/',sep='')

####################
#input

#early neurogenic progra,s
program_path = paste(program_dir,'program.txt',sep='')

#LoFi genes
LoFi_path = paste(LoFi_dir,'LoFi.txt',sep='')

####################
#output

#log file
log_path = paste(root_dir,'code/gene set/LoFi/log/LoFi_program_partition.log',sep='')

partition_path = paste(LoFi_dir,'LoFi_program_partition.txt',sep='')

######################
#other
program_names = c('expressed', 'early_increasing_ko','early_stable_ko','early_transient_ko')

#######################################################################
# functions
#######################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of ncbi/entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','ncbi'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}

########################################################################################
#extract overlap with downregulated genes & these save gene-sets (& covariates) to file
write_MAGMA <- function(path,data) {
	
	entrez_ids = mapply(function(k) paste(data[[k]],sep='',collapse = ' '),names(data))
	
	magma_table = data.table(ann = names(data), entrez = entrez_ids)
	
	write.table(magma_table,file = path,row.names = FALSE,col.names = FALSE,sep = '\t',quote = FALSE)
	
	cat('Gene sets written to file',path,'\n\n')
}

##########################################################################
#initialisation
###########################################################################
#log file
sink(file = log_path, append = F)
#########################################################################################################################################
# main - start
#########################################################################################################################################
#read LoFi gene-set
LoFi_set = read_MAGMA(LoFi_path)$LoFi

#read program gene-sets - need all expressed as covariate
program_data = read_MAGMA(program_path)[program_names]
	
cat(length(program_data),' gene-sets read from file: ',program_path,'\n\n')
for (next_ann in names(program_data)) {
	
	cat(next_ann,length(program_data[[next_ann]]),'\n')
}
cat('\n')

###############################
#collate gene sets for analysis
collated_data = list('expressed' = program_data$expressed)

LoFi_overlap = c()

for (next_name in program_names[(2:length(program_names))]) {
	
	next_set = program_data[[next_name]]
	
	next_overlap = intersect(next_set,LoFi_set)
	
	collated_data[[paste(next_name,'_NOT_LoFi',sep='')]] = setdiff(next_set,LoFi_set)
	collated_data[[paste(next_name,'_AND_LoFi',sep='')]] = next_overlap
	
	LoFi_overlap = union(LoFi_overlap,next_overlap)
}

collated_data[['LoFi_other']] = setdiff(LoFi_set,LoFi_overlap)

cat(length(collated_data),'gene-sets collated:\n')
for (next_ann in names(collated_data)) {
	
	cat(next_ann,length(collated_data[[next_ann]]),'\n')
}
cat('\n')

#save these gene-sets (&) to file
write_MAGMA(partition_path,collated_data)	


##############################
#stop sending data to log file
sink()