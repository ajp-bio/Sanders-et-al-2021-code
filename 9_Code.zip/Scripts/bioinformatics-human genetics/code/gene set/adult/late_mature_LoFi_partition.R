#!/usr/bin/Rscript

#work
#source('.../code/gene set/adult/late_mature_LoFi_partition.R')

#################################################################################
#required libraries
suppressMessages(library(data.table))
library(Matrix)
#######################################################################
# Variables
#######################################################################
root_dir = ".../"

LoFi_dir = paste(root_dir,'working/gene set/LoFi/',sep='')
mature_dir = paste(root_dir,'working/gene set/adult/',sep='')

####################
#input

#LoFi genes partitioned by early neurogenic programs
LoFi_path = paste(LoFi_dir,'LoFi_program_partition.txt',sep='')

#mature neuronal genes (top 10% CA1 pyramidal specific) partitioned by early neurogenic programs
mature_path = paste(mature_dir,'mature_program_partition.txt',sep='')

####################
#output

#log file
log_path = paste(root_dir,'code/gene set/adult/log/late_mature_LoFi_partition.log',sep='')

partition_path = paste(mature_dir,'late_mature_LoFi_partition.txt',sep='')

######################
#other
mature_names = c('expressed','late_AND_pyramidal_CA1_specificity_10_percent','pyramidal_CA1_specificity_10_percent_other')
LoFi_names = c('LoFi_other')
#######################################################################
# functions
#######################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of ncbi/entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','ncbi'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,ncbi],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}

########################################################################################
#extract overlap with downregulated genes & these save gene-sets (& covariates) to file
write_MAGMA <- function(path,data) {
	
	entrez_ids = mapply(function(k) paste(data[[k]],sep='',collapse = ' '),names(data))
	
	magma_table = data.table(ann = names(data), entrez = entrez_ids)
	
	write.table(magma_table,file = path,row.names = FALSE,col.names = FALSE,sep = '\t',quote = FALSE)
	
	cat('Gene sets written to file',path,'\n\n')
}

##########################################################################
#initialisation
###########################################################################
#log file
sink(file = log_path, append = F)
#########################################################################################################################################
# main - start
#########################################################################################################################################
#read mature gene-sets
mature_data = read_MAGMA(mature_path)[mature_names]

cat(length(mature_data),' gene-sets read from file: ',mature_path,'\n\n')
for (next_ann in names(mature_data)) {
	
	cat(next_ann,length(mature_data[[next_ann]]),'\n')
}
cat('\n')

#read LoFi gene-sets
LoFi_data = read_MAGMA(LoFi_path)[LoFi_names]
	
cat(length(LoFi_data),' gene-sets read from file: ',LoFi_path,'\n\n')
for (next_ann in names(LoFi_data)) {
	
	cat(next_ann,length(LoFi_data[[next_ann]]),'\n')
}
cat('\n')

LoFi_set = LoFi_data$LoFi_other
LoFi_name = 'LoFi_outside_early'

###############################
#collate gene sets for analysis
collated_data = list('expressed' = mature_data$expressed)

LoFi_overlap = c()

for (next_name in mature_names[(2:length(mature_names))]) {
	
	next_set = mature_data[[next_name]]
	
	next_overlap = intersect(next_set,LoFi_set)
	
	collated_data[[paste(next_name,'NOT',LoFi_name,sep='_')]] = setdiff(next_set,LoFi_set)
	collated_data[[paste(next_name,'AND',LoFi_name,sep='_')]] = next_overlap
	
	LoFi_overlap = union(LoFi_overlap,next_overlap)
	
}

collated_data[[paste(LoFi_name,'remainder',sep='_')]] = setdiff(LoFi_set,LoFi_overlap)


cat(length(collated_data),'gene-sets collated:\n')
for (next_ann in names(collated_data)) {
	
	cat(next_ann,length(collated_data[[next_ann]]),'\n')
}
cat('\n')

#save these gene-sets (&) to file
write_MAGMA(partition_path,collated_data)	


##############################
#stop sending data to log file
sink()