#!/usr/bin/Rscript

#work
#source('.../code/gene set/ko-wt partition/ko_wt_partition.R')


#################################################################################
#required libraries
suppressMessages(library(data.table))
library(Matrix)
#######################################################################
# Variables
#######################################################################
root_dir = ".../"

data_dir = paste(root_dir,'working/gene set/',sep='')
####################
#input

wt_path = paste(data_dir,'wt/all_days.txt',sep='')
ko_wt_path = paste(data_dir,'ko v wt/all_days.txt',sep='')

####################
#output

partition_path = paste(data_dir,'ko-wt partition/ko_wt_partition.txt',sep='')

#log file
log_path = paste(root_dir,'code/gene set/ko-wt partition/log/ko_wt_partition.log',sep='')

####################
#other

wt_names = c('expressed','day_30_v_20_up')
ko_wt_names = c('expressed','day_30_down')
#######################################################################
# functions
#######################################################################
#read gene annotations from MAGMA format file: 2 tab-delimited fields (no field names/header), 1 line per gene-set
#field 1 = annotation name
#field 2 = space (' ') separated list of entrez gene ids
# e.g.
#ann_name1	entrez1 entrez2 entrez3 ...
#ann_name2...
read_MAGMA <- function(next_path) {
	
	tmp = fread(next_path,header = FALSE,col.names = c('ann','entrez'))
	
	tmp_list = lapply(tmp$ann,function(k) unlist(strsplit(tmp[ann == k,entrez],' ',fixed = TRUE)))
	names(tmp_list) = tmp$ann
	
	return(tmp_list)
}
########################################################################################
#extract overlap with downregulated genes & these save gene-sets (& covariates) to file
write_MAGMA <- function(path,data) {
	
	entrez_ids = mapply(function(k) paste(data[[k]],sep='',collapse = ' '),names(data))
	
	magma_table = data.table(ann = names(data), entrez = entrez_ids)
	
	write.table(magma_table,file = path,row.names = FALSE,col.names = FALSE,sep = '\t',quote = FALSE)
	
	cat('Writing gene sets to file',path,'\n\n')
}
##########################################################################
#initialisation
###########################################################################
#log file
sink(file = log_path, append = F)
#########################################################################################################################################
# main - start
#########################################################################################################################################

#read data files & extract gene sets
wt_data = read_MAGMA(wt_path)[wt_names]
ko_wt_data = read_MAGMA(ko_wt_path)[ko_wt_names]

cat(length(wt_data),'gene-sets read from file:',wt_path,'\n\n')
for (k in names(wt_data)) { cat(length(wt_data[[k]]),'\t',k,'\n')}
cat('\n')

cat(length(ko_wt_data),'gene-sets read from file:',ko_wt_path,'\n\n')
for (k in names(ko_wt_data)) { cat(length(ko_wt_data[[k]]),'\t',k,'\n')}
cat('\n')

#Partition wt sets for further analysis
partition_data = list('expressed' = union(ko_wt_data$expressed,wt_data$expressed))

name_1 = 'day_30_down'
set_1 = ko_wt_data[[name_1]]

#for each wt set
for (name_2 in wt_names[(2:length(wt_names))]) {
	
	set_2 = wt_data[[name_2]]
	
	set_1_and_2 = intersect(set_1,set_2)
	set_1_not_2 = setdiff(set_1,set_2)
	set_2_not_1 = setdiff(set_2,set_1)
	
	name_1_and_2 = paste(name_1,'_AND_',name_2,sep='')
	name_1_not_2 = paste(name_1,'_NOT_',name_2,sep='')
	name_2_not_1 = paste(name_2,'_NOT_',name_1,sep='')
	
	partition_data[[name_1_and_2]] = set_1_and_2
	partition_data[[name_1_not_2]] = set_1_not_2
	partition_data[[name_2_not_1]] = set_2_not_1
	
	cat(length(set_1_and_2),'genes common to',name_1,'and',name_2,'\n')
	cat(round(100*length(set_1_and_2)/length(set_1)),'percent of',name_1,'\n')
	cat(round(100*length(set_1_and_2)/length(set_2)),'percent of',name_2,'\n\n')
}


#save gene-sets for analysis
write_MAGMA(partition_path, partition_data)

cat('Partitioned gene-sets written to file:',partition_path,'\n\n')
for (k in names(partition_data)) { cat(length(partition_data[[k]]),k,'\n')}
cat('\n')
##############################
#stop sending data to log file
sink()