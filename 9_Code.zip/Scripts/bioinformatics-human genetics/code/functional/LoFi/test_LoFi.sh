#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#early neurogenic programs
Rscript set_enrich_test.R --ann_path '.../working/gene set/LoFi/LoFi.txt' --set_path '.../working/gene set/program/program.txt' --ann_format magma --set_format magma --set_names late,early_increasing_ko,early_stable_ko,early_transient_ko --bkgd_name expressed --alt two.sided --p_thr 0.05 --p_refine_thr 0.05 --core 10 --collate T --dest_dir '.../processed/functional/LoFi/'