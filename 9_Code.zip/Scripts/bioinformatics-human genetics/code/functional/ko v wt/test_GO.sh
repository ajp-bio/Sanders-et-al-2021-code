#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#day_30 down-regulated
Rscript set_enrich_test.R --ann_path '.../working/gene set/GO/GO_strict_coding_20_2000.txt' --set_path '.../working/gene set/ko v wt/day_30.txt' --ann_format standard --set_format magma --set_names day_30_down --bkgd_name day_30_expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --ann_min 20 --ann_max 2000 --dest_dir '.../processed/functional/GO/ko v wt/'