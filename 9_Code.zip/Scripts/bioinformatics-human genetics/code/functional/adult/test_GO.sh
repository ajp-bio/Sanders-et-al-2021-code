#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#early-stable/mature partition
Rscript set_enrich_test.R --ann_path '.../working/gene set/GO/GO_strict_coding_20_2000.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format standard --set_format magma --set_names early_stable_ko_AND_pyramidal_CA1_specificity_10_percent,early_stable_ko_NOT_pyramidal_CA1_specificity_10_percent --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --ann_min 20 --ann_max 2000 --collate T --dest_dir '.../processed/functional/adult/GO/stable/'

#early-increasing/mature partition
Rscript set_enrich_test.R --ann_path '.../working/gene set/GO/GO_strict_coding_20_2000.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format standard --set_format magma --set_names early_increasing_ko_AND_pyramidal_CA1_specificity_10_percent,early_increasing_ko_NOT_pyramidal_CA1_specificity_10_percent --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --ann_min 20 --ann_max 2000 --collate T --dest_dir '.../processed/functional/adult/GO/increasing/'

#late/mature partition
Rscript set_enrich_test.R --ann_path '.../working/gene set/GO/GO_strict_coding_20_2000.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format standard --set_format magma --set_names late_AND_pyramidal_CA1_specificity_10_percent,late_NOT_pyramidal_CA1_specificity_10_percent --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --ann_min 20 --ann_max 2000 --collate T --dest_dir '.../processed/functional/adult/GO/late/'

#remaining mature genes
Rscript set_enrich_test.R --ann_path '.../working/gene set/GO/GO_strict_coding_20_2000.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format standard --set_format magma --set_names pyramidal_CA1_specificity_10_percent_other --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --ann_min 20 --ann_max 2000 --collate T --dest_dir '.../processed/functional/adult/GO/other/'

