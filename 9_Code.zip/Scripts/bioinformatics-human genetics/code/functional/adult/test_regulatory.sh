#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#late/mature intersection
Rscript set_enrich_test.R --ann_path '.../working/gene set/regulatory/regulatory.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format magma --set_format magma --set_names late_AND_pyramidal_CA1_specificity_10_percent --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --dest_dir '.../processed/functional/adult/regulatory/'