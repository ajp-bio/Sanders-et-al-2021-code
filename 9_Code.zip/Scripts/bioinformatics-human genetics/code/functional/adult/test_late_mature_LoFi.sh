#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#late/mature partitions
Rscript set_enrich_test.R --ann_path '.../working/gene set/LoFi/LoFi.txt' --set_path '.../working/gene set/adult/mature_program_partition.txt' --ann_format magma --set_format magma --set_names late_NOT_pyramidal_CA1_specificity_10_percent,late_AND_pyramidal_CA1_specificity_10_percent,pyramidal_CA1_specificity_10_percent_other --bkgd_name expressed --alt two.sided --p_thr 0.05 --p_refine_thr 0.05 --core 10 --collate T --dest_dir '.../processed/functional/adult/LoFi/'