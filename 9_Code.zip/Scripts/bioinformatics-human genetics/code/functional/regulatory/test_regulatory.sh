#!/bin/bash

cd '.../auxiliary/'

##############################################################################


#early-increasing (ko)
Rscript set_enrich_test.R --ann_path '.../working/gene set/regulatory/regulatory.txt' --set_path '.../working/gene set/program/program.txt' --ann_format magma --set_format magma --set_names early_increasing_ko --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --dest_dir '.../processed/functional/regulatory/increasing/'

#early-stable (ko)
Rscript set_enrich_test.R --ann_path '.../working/gene set/regulatory/regulatory.txt' --set_path '.../working/gene set/program/program.txt' --ann_format magma --set_format magma --set_names early_stable_ko --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --dest_dir '.../processed/functional/regulatory/stable/'

#early-transient (ko)
Rscript set_enrich_test.R --ann_path '.../working/gene set/regulatory/regulatory.txt' --set_path '.../working/gene set/program/program.txt' --ann_format magma --set_format magma --set_names early_transient_ko --bkgd_name expressed --alt greater --p_thr 0.05 --p_refine_thr 0.05 --core 10 --dest_dir '.../processed/functional/regulatory/transient/'