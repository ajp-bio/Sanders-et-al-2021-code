#!/bin/bash

cd '.../auxiliary/'

####################
## ASD
####################

#conditioned on expressed
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/ASD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_ASD.txt' --ann_path '.../working/gene set/LoFi/LoFi_program_partition.txt' --dest_path '.../processed/snv/ASD/LoFi/LoFi_program_partition_cond' --ann_format magma --base_set expressed --indep T --alt two.sided --class LoF

####################
## SIB
####################

#conditioned on expressed
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/ASD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_SIB.txt' --ann_path '.../working/gene set/LoFi/LoFi_program_partition.txt' --dest_path '.../processed/snv/SIB/LoFi/LoFi_program_partition_cond' --ann_format magma --base_set expressed --indep T --alt two.sided --class LoF

####################
## DD
####################


Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/DD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_NDD.txt' --ann_path '.../working/gene set/LoFi/LoFi_program_partition.txt' --dest_path '.../processed/snv/DD/LoFi/LoFi_program_partition_cond' --ann_format magma --base_set expressed --indep T --alt two.sided --class LoF

####################
## SZ
####################

#conditioned on expressed
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/SZ/2019/Rees 19/processed/combined_trios_dnv_gene_counts.txt' --ann_path '.../working/gene set/LoFi/LoFi_program_partition.txt' --dest_path '.../processed/snv/SZ/LoFi/LoFi_program_partition_cond' --ann_format magma --base_set expressed --indep T --alt two.sided --class LoF

