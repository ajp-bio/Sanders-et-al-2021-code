#!/bin/bash

cd '.../auxiliary/'

####################
## ASD
####################

#early increasing
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/ASD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_ASD.txt' --ann_path '.../working/gene set/program/functional/increasing_ko_GO.txt' --dest_path '.../processed/snv/ASD/program/early_increasing_ko_GO' --ann_format magma --base_set early_increasing_ko --indep T --alt two.sided --class LoF

#early stable
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/ASD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_ASD.txt' --ann_path '.../working/gene set/program/functional/stable_ko_GO.txt' --dest_path '.../processed/snv/ASD/program/early_stable_ko_GO' --ann_format magma --base_set early_stable_ko --indep T --alt two.sided --class LoF

#early transient
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/ASD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_ASD.txt' --ann_path '.../working/gene set/program/functional/transient_ko_GO.txt' --dest_path '.../processed/snv/ASD/program/early_transient_ko_GO' --ann_format magma --base_set early_transient_ko --indep T --alt two.sided --class LoF


####################
## DD
####################

#early increasing
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/DD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_NDD.txt' --ann_path '.../working/gene set/program/functional/increasing_ko_GO.txt' --dest_path '.../processed/snv/DD/program/early_increasing_ko_GO' --ann_format magma --base_set early_increasing_ko --indep T --alt two.sided --class LoF

#early stable
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/DD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_NDD.txt' --ann_path '.../working/gene set/program/functional/stable_ko_GO.txt' --dest_path '.../processed/snv/DD/program/early_stable_ko_GO' --ann_format magma --base_set early_stable_ko --indep T --alt two.sided --class LoF

#early transient
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/DD/Satterstrom 19/processed/gene/Satterstrom2019_denovo_counts_coding_NDD.txt' --ann_path '.../working/gene set/program/functional/transient_ko_GO.txt' --dest_path '.../processed/snv/DD/program/early_transient_ko_GO' --ann_format magma --base_set early_transient_ko --indep T --alt two.sided --class LoF


####################
## SZ
####################

#early increasing
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/SZ/2019/Rees 19/processed/combined_trios_dnv_gene_counts.txt' --ann_path '.../working/gene set/program/functional/increasing_ko_GO.txt' --dest_path '.../processed/snv/SZ/program/early_increasing_ko_GO' --ann_format magma --base_set early_increasing_ko --indep T --alt two.sided --class LoF

#early stable
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/SZ/2019/Rees 19/processed/combined_trios_dnv_gene_counts.txt' --ann_path '.../working/gene set/program/functional/stable_ko_GO.txt' --dest_path '.../processed/snv/SZ/program/early_stable_ko_GO' --ann_format magma --base_set early_stable_ko --indep T --alt two.sided --class LoF

#early transient
Rscript denovo_snv_rate_ratio_test.R --mut_path '/Users/andrew/Data/variation/snv-indel/mutation rates/2017/processed/mutation_prob.txt' --denovo_path '/Users/andrew/Data/variation/snv-indel/de novo/SZ/2019/Rees 19/processed/combined_trios_dnv_gene_counts.txt' --ann_path '.../working/gene set/program/functional/transient_ko_GO.txt' --dest_path '.../processed/snv/SZ/program/early_transient_ko_GO' --ann_format magma --base_set early_transient_ko --indep T --alt two.sided --class LoF

