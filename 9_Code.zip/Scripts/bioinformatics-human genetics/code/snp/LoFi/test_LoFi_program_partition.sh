#!/bin/bash



###########################################################################################################
# Test partitioned sets for enrichment in SZ GWAS association
###########################################################################################################

./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/LoFi/LoFi_program_partition'


##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done