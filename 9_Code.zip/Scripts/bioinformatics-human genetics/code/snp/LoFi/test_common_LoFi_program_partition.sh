#!/bin/bash



###################################################################################################################
# Test partitioned sets for enrichment in GWAS association (Disorders with shared heritability, plus AD as control)
###################################################################################################################

#ASD
./magma --gene-results  '.../working/snp/ASD/ASD2019.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/ASD/LoFi/LoFi_program_partition'

#ADHD
./magma --gene-results  '.../working/snp/ADHD/ADHD2017.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/ADHD/LoFi/LoFi_program_partition'

#BP
./magma --gene-results  '.../working/snp/BP/BP2018.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/BP/LoFi/LoFi_program_partition'

#MDD
./magma --gene-results  '.../working/snp/MDD/MDD2018.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/MDD/LoFi/LoFi_program_partition'

#IQ
./magma --gene-results  '.../working/snp/IQ/IQ2018.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/IQ/LoFi/LoFi_program_partition'

#AD
./magma --gene-results  '.../working/snp/AD/IGAP.raw' --set-annot '.../working/gene set/LoFi/LoFi_program_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/AD/LoFi/LoFi_program_partition_2019'


##############################################################################################
##############################################################################################
# Rename .out -> .txt

#ASD
cd '.../processed/snp/ASD/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#ADHD
cd '.../processed/snp/ADHD/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#BP
cd '.../processed/snp/BP/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#MDD
cd '.../processed/snp/MDD/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#IQ
cd '.../processed/snp/IQ/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#AD
cd '.../processed/snp/AD/LoFi/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done