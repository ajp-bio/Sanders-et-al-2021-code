#!/bin/bash



###########################################################################################################
#Test partitioned ko v wt & wt gene sets (all genes expressed at one or more timepoint as covariate
###########################################################################################################

./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko-wt partition/ko_wt_partition.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/ko-wt partition/ko_wt_partition'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/ko-wt partition/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done