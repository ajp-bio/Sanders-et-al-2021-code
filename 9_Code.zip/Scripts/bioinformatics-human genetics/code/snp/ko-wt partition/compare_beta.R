###################################
#source(".../code/snp/ko-wt partition/compare_beta.R")

root_dir = '.../'
snp_dir = paste(root_dir,'processed/snp/SZ/ko-wt partition/',sep='')

snp_fname = 'ko_wt_partition.gsa.txt'
dest_fname = 'ko_wt_partition_beta_compare.txt'


test_ann = list('day_30_down_AND_day_30_v_20_up' = c('day_30_down_NOT_day_30_v_20_up','day_30_v_20_up_NOT_day_30_down'))
##############################################################################################
#functions

compare_ann <- function(ann_data,ann_1,ann_2,hypothesis) {
	
	ann_1_beta = ann_data[ann_1,'BETA']
	ann_1_se = ann_data[ann_1,'SE']
	ann_2_beta = ann_data[ann_2,'BETA']
	ann_2_se = ann_data[ann_2,'SE']
	
	p = compare_beta(ann_1_beta,ann_2_beta,ann_1_se,ann_2_se,hypothesis)
	
	c(ann_1,ann_1_beta,ann_1_se,ann_2,ann_2_beta,ann_2_se,p)
}

#test for significant difference between betas
compare_beta <- function(b_1,b_2,se_1,se_2,hypothesis) {
	
	se_d = sqrt(se_1**2 + se_2**2)
	
	if(hypothesis == 'different') {
		
		z = -abs(b_1-b_2)/se_d
		p = 2*pnorm(z,mean = 0,sd = 1,lower.tail = TRUE)
		
	} else if(hypothesis == 'greater') {
		
		z = -(b_1-b_2)/se_d
		p = pnorm(z,mean = 0,sd = 1,lower.tail = TRUE)
		
	}  else if(hypothesis == 'lower') {
		
		z = (b_1-b_2)/se_d
		p = pnorm(z,mean = 0,sd = 1,lower.tail = TRUE)
		
	} else { p = NA }
	
	p

}
##############################################################################################
	
#read MAGMA results summary
snp_data = read.table(paste(snp_dir,snp_fname,sep=''),row.names = 8,sep = '',header = TRUE,as.is = TRUE,quote = '',comment.char = '#')
	
results = NULL
for (next_ann in names(test_ann)) {
	
	next_results = as.data.frame(t(mapply(function(k) compare_ann(snp_data,next_ann,k,'greater'),test_ann[[next_ann]])))
	
	tmp = rbind(results,next_results)
	results = tmp
}

names(results) = c('ann_1','beta_1','se_1','ann_2','beta_2','se_2','P (greater)')
	
################
#save results
write.table(results,file = paste(snp_dir,dest_fname,sep=''),row.names = FALSE,col.names = TRUE,sep = '\t',quote = FALSE)