#!/bin/bash


###########################################################################################################
# Test subsets of program genes belonging to over-represented GO terms
###########################################################################################################

#early-increasing (ko)
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/regulatory/program/increasing_ko_regulatory.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/SZ/regulatory/increasing_ko_regulatory'

#early-stable (ko)
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/regulatory/program/stable_ko_regulatory.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/SZ/regulatory/stable_ko_regulatory'

#early-transient (ko)
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/regulatory/program/transient_ko_regulatory.txt' --model direction-sets = twosided condition-residualize = expressed, early_transient_ko --out '.../processed/snp/SZ/regulatory/transient_ko_regulatory'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/regulatory/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done