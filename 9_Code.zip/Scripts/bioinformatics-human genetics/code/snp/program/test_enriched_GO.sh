#!/bin/bash


###########################################################################################################
# Test subsets of program genes belonging to over-represented GO terms
###########################################################################################################

#early-increasing (ko)
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/SZ/program/functional/increasing_ko_GO'

#early-stable (ko)
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/SZ/program/functional/stable_ko_GO'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done