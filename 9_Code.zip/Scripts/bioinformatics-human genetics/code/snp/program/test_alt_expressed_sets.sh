#!/bin/bash


###########################################################################################################
#Test program sets (in vivo expressed genes (excitatory newborn/developing neurons)as covariate
###########################################################################################################

#in vivo genes with non-zero expression
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/program/alt_expressed_non_zero.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/program/alt expressed/non_zero'

#in vivo genes expressed in at least 5% newborn/developing cells
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/program/alt_expressed_filtered_5_percent.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/program/alt expressed/filtered_5_percent'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/program/alt expressed/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done