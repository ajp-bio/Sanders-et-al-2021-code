#!/bin/bash


###########################################################################################################
# Test subsets of program genes belonging to over-represented GO terms
###########################################################################################################

#ASD

##early-increasing (ko)
./magma --gene-results  '.../working/snp/ASD/ASD2019.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/ASD/program/functional/increasing_ko_GO'

##early-stable (ko)
./magma --gene-results  '.../working/snp/ASD/ASD2019.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/ASD/program/functional/stable_ko_GO'


#ADHD

##early-increasing (ko)
./magma --gene-results  '.../working/snp/ADHD/ADHD2017.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/ADHD/program/functional/increasing_ko_GO'

##early-stable (ko)
./magma --gene-results  '.../working/snp/ADHD/ADHD2017.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/ADHD/program/functional/stable_ko_GO'


#BP

##early-increasing (ko)
./magma --gene-results  '.../working/snp/BP/BP2018.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/BP/program/functional/increasing_ko_GO'

##early-stable (ko)
./magma --gene-results  '.../working/snp/BP/BP2018.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/BP/program/functional/stable_ko_GO'


#MDD

##early-increasing (ko)
./magma --gene-results  '.../working/snp/MDD/MDD2018.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/MDD/program/functional/increasing_ko_GO'

##early-stable (ko)
./magma --gene-results  '.../working/snp/MDD/MDD2018.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/MDD/program/functional/stable_ko_GO'


#IQ

##early-increasing (ko)
./magma --gene-results  '.../working/snp/IQ/IQ2018.raw' --set-annot '.../working/gene set/program/functional/increasing_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_increasing_ko --out '.../processed/snp/IQ/program/functional/increasing_ko_GO'

##early-stable (ko)
./magma --gene-results  '.../working/snp/IQ/IQ2018.raw' --set-annot '.../working/gene set/program/functional/stable_ko_GO.txt' --model direction-sets = twosided condition-residualize = expressed, early_stable_ko --out '.../processed/snp/IQ/program/functional/stable_ko_GO'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

#ASD
cd '.../processed/snp/ASD/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#ADHD
cd '.../processed/snp/ADHD/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#BP
cd '.../processed/snp/BP/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#MDD
cd '.../processed/snp/MDD/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done

#IQ
cd '.../processed/snp/IQ/program/functional/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done
