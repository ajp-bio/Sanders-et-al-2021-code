#!/bin/bash


###########################################################################################################
#Test up-/down-regulated gens for each timepoint (all genes expressed at one or more timepoint as covariate
###########################################################################################################


./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/wt/all_days.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/wt/collated/all_days'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/wt/collated/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done