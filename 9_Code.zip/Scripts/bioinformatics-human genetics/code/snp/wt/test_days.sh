#!/bin/bash


##############################################################################

# day_20_v_15
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/wt/day_20_v_15.txt' --model condition-residualize = day_20_v_15_expressed --out '.../processed/snp/SZ/wt/days/day_20_v_15'

# day_30_v_20
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/wt/day_30_v_20.txt' --model condition-residualize = day_30_v_20_expressed --out '.../processed/snp/SZ/wt/days/day_30_v_20'

# day_60_v_30
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/wt/day_60_v_30.txt' --model condition-residualize = day_60_v_30_expressed --out '.../processed/snp/SZ/wt/days/day_60_v_30'


##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/wt/days/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done