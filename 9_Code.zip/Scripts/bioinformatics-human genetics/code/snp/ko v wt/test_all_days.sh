#!/bin/bash



##############################################################################################
#Test set of all genes expressed at one or more timepoint
##############################################################################################


./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/all_days.txt' --model analyse = list,expressed --out '.../processed/snp/SZ/ko v wt/collated/expressed'

###########################################################################################################
#Test up-/down-regulated gens for each timepoint (all genes expressed at one or more timepoint as covariate
###########################################################################################################

./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/all_days.txt' --model condition-residualize = expressed --out '.../processed/snp/SZ/ko v wt/collated/all_days'

##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/ko v wt/collated/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done