#!/bin/bash


##############################################################################

# day_15
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/day_15.txt' --model condition-residualize = day_15_expressed --out '.../processed/snp/SZ/ko v wt/days/day_15'

# day_20
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/day_20.txt' --model condition-residualize = day_20_expressed --out '.../processed/snp/SZ/ko v wt/days/day_20'

# day_30
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/day_30.txt' --model condition-residualize = day_30_expressed --out '.../processed/snp/SZ/ko v wt/days/day_30'


# day_60
./magma --gene-results  '.../working/snp/SZ/SZ2018.raw' --set-annot '.../working/gene set/ko v wt/day_60.txt' --model condition-residualize = day_60_expressed --out '.../processed/snp/SZ/ko v wt/days/day_60'


##############################################################################################
##############################################################################################
# Rename .out -> .txt

cd '.../processed/snp/SZ/ko v wt/days/'
for f in *.out; do mv "$f" "${f/.out/.txt}"; done